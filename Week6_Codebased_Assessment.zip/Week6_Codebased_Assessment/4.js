function squareNumbers(numbers) {
    
    return numbers.map(number => number * number);
}


const numbersArray = [1, 2, 3, 4, 5];
const squaredArray = squareNumbers(numbersArray);

console.log(squaredArray); // Output: [1, 4, 9, 16, 25]