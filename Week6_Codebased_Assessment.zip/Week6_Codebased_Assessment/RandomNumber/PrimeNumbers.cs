﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RandomNumber
{
    internal class PrimeNumbers
    {
        static void Main()
        {
            Console.Write("Enter the number of prime numbers: ");

            if (int.TryParse(Console.ReadLine(), out int n) && n > 0)
            {
                GenerateAndDisplayPrimes(n);
                
            }
            else
            {
                Console.WriteLine("Please enter a valid positive integer.");
            }
        }
        static void GenerateAndDisplayPrimes(int count)
        {
            int num = 2;
            int foundPrimes = 0;

            while (foundPrimes < count)
            {
                if (IsPrime(num))
                {
                    Console.Write(num + " ");
                    foundPrimes++;
                }
                num++;
            }

            Console.WriteLine(); 
        }
        static bool IsPrime(int number)
        {
            if (number <= 1)
                return false;
            if (number == 2)
                return true;
            if (number % 2 == 0)
                return false;

            for (int i = 3; i <= Math.Sqrt(number); i += 2)
            {
                if (number % i == 0)
                    return false;
            }

            return true;
        }
    }
}
        

