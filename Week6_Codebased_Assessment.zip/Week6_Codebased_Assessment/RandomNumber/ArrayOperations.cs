﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RandomNumber
{
    internal class ArrayOperations
    {
        static void Main()
        {
            int[] numbers = { 3, 7, 2, 9, 5, 8, 4 };

            int sum = numbers.Sum();

            double average=numbers.Average();
            int max=numbers.Max();
            int min=numbers.Min();
            Console.WriteLine($"Array: {string.Join(", ", numbers)}");
            Console.WriteLine($"Sum: {sum}");
            Console.WriteLine($"Average: {average:F2}"); // F2 formats the average to 2 decimal places
            Console.WriteLine($"Maximum: {max}");
            Console.WriteLine($"Minimum: {min}");
        }
    }
}
