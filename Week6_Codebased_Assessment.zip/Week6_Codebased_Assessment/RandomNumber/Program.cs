﻿namespace RandomNumber
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int minNumber = 1;
            int maxNumber = 50;
            int maxAttempts = 5;
            Random random = new Random();

            int targetNumber = random.Next(minNumber, maxNumber + 1);

            Console.WriteLine($"Guess the number between {minNumber} and {maxNumber}. You have {maxAttempts} attempts.");

            int attemptsLeft = maxAttempts;
            while (attemptsLeft > 0)
            {
                Console.WriteLine("Enter your guess: ");
                string input = Console.ReadLine();
                if (int.TryParse(input, out int guess))
                {
                    if (guess < minNumber || guess > maxNumber)
                    {
                        Console.WriteLine($"Please enter a number between {minNumber} and {maxNumber}.");
                        continue;
                    }
                    if (guess == targetNumber)
                    {
                        Console.WriteLine("Congratulations! You guessed the number correctly.");
                        break;
                    }
                    else
                    {
                        attemptsLeft--;
                        if (attemptsLeft > 0)
                        {
                            Console.WriteLine($"Wrong guess. You have {attemptsLeft} attempts left.");
                        }
                        else
                        {
                            Console.WriteLine($"Sorry, you've run out of attempts. The correct number was {targetNumber}.");
                        }
                    }
                }
            }
        }
    }
}
