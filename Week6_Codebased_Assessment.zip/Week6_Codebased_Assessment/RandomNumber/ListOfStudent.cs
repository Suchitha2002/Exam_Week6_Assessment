﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RandomNumber
{
    class ListOfStudent
    {
        public class Student
        {
            public int ID { get; set; }
            public string Name { get; set; }
        }
        public class Enrollment
        {
            public int StudentID { get; set; }
            public string Course { get; set; }
        }
        static void Main()
        {
            // Create a list of students
            List<Student> students = new List<Student>
            {
                new Student { ID = 1, Name = "Alice" },
                new Student { ID = 2, Name = "Bob" },
                new Student { ID = 3, Name = "Charlie" }
            };
            // Create a list of enrollments
            List<Enrollment> enrollments = new List<Enrollment>
            {
                new Enrollment { StudentID = 1, Course = "Mathematics" },
                new Enrollment { StudentID = 1, Course = "Science" },
                new Enrollment { StudentID = 2, Course = "English" },
                new Enrollment { StudentID = 3, Course = "Mathematics" }
            };
            // LINQ query to retrieve students along with their enrolled courses
            var studentCourses = from student in students
                                 join enrollment in enrollments
                                 on student.ID equals enrollment.StudentID
                                 group new { student.Name, enrollment.Course } by student.Name into studentGroup
                                 select new
                                 {
                                     StudentName = studentGroup.Key,
                                     Courses = studentGroup.Select(x => x.Course).ToList()
                                 };
            // Display the results
            foreach (var student in studentCourses)
            {
                Console.WriteLine($"Student: {student.StudentName}");
                Console.WriteLine("Courses: " + string.Join(", ", student.Courses));
                Console.WriteLine();
            }

            Console.WriteLine("Press any key to exit.");
            Console.ReadKey();








        }
    }
}
